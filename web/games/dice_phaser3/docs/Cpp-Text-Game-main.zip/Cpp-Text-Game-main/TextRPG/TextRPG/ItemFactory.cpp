#include "ItemFactory.h"

Item ItemFactory::CreateCigarette(int quantity) {
	return Item(
		"���",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			10,// hp
			0, // mp
			0, // str
			0, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		20
	);
}

Item ItemFactory::CreateAlcohol(int quantity) {
	return Item(
		"��",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			0,// hp
			10, // mp
			0, // str
			0, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		15
	);
}

Item ItemFactory::CreateDrug(int quantity) {
	return Item(
		"����",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			10, // att
		   -10, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		40
	);
}

Item ItemFactory::CreateWhiskey(int quantity) {
	return Item(
		"����Ű",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			0,// hp
			20, // mp
			0, // str
			0, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		35
	);
}

Item ItemFactory::CreateSyringe(int quantity) {
	return Item(
		"�ֻ��",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			10,// hp
			10, // mp
			0, // str
			15, // att
		   -15, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		100
	);
}

Item ItemFactory::CreateCannabis(int quantity) {
	return Item(
		"�븶��",
		ItemType::Consumable,
		EquipmentType::None,
		StatBonus(
			20,// hp
			0, // mp
			0, // str
			0, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		quantity,
		40
	);
}

//��� ������(����)
Item ItemFactory::CreateKnife() {
	return Item(
		"������",
		ItemType::Equipment,
		EquipmentType::Weapon,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			20, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		300
	);
}

Item ItemFactory::CreateBat() {
	return Item(
		"�߱���Ʈ",
		ItemType::Equipment,
		EquipmentType::Weapon,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			15, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		250
	);
}

Item ItemFactory::CreateKnuckle() {
	return Item(
		"��Ŭ",
		ItemType::Equipment,
		EquipmentType::Weapon,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			10, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		200
	);
}

Item ItemFactory::CreateKatana() {
	return Item(
		"īŸ��",
		ItemType::Equipment,
		EquipmentType::Weapon,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			40, // att
			0, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		500
	);
}

//��� ������(�Ƹ�)
Item ItemFactory::CreateThomBrowne() {
	return Item(
		"�� ����",
		ItemType::Equipment,
		EquipmentType::Armor,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			0, // att
			20, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		300
	);
}

Item ItemFactory::CreateGucci() {
	return Item(
		"����",
		ItemType::Equipment,
		EquipmentType::Armor,
		StatBonus(
			0,// hp
			0, // mp
			0, // str
			0, // att
			20, // def
			0, // dex
			0, // intel
			0 // luk 
		),
		1,
		300
	);
}

//����Ʈ ������(ȿ�� ����)
Item ItemFactory::CreateQuestKey() {
	return Item(
		"����Ʈ Ű",
		ItemType::Quest,
		EquipmentType::None,
		StatBonus(),
		1,
		0
	);
}