#pragma once

#include "GameContext.h"
#include "Shop.h"
#include "GameState.h"
#include "UIScreen.h"
#include "Inventory.h"
#include "ConsolUI.h"
#include "InputManager.h"
#include "BattleResult.h"


class GameManager
{
public:

    GameManager();
    ~GameManager();

    void Run();

private:

    // ����
    GameState currentState;

    // ���� ������
    GameContext context;
    Shop shop;

    // �ý��� ����
    bool loadSuccess;
    bool isWin;
    bool playerLevelUp;
    bool IsShop;

    // UI ������
    std::vector<std::string> logs;
    std::vector<std::string> playerStatus;
    std::vector<std::string> monsterStatus;

    std::vector<int> shopIndexMap;


    //ĳ���� ���� ���� 0 :��, 1 : ��
    int selectedCharacterIndex = 0; 

private:

    // �ʱ�ȭ
    void Initialize();

    // �ƽ�
    void PlayOpeningCutscenes();

    void RenderCharacterSelect();

    void RenderMainMenu();

    void RenderShop();

    void RenderInventory();

    void RenderStatus();

    void RenderStory();

    void HandleCharacterSelectInput();

    void HandleMainMenuInput();

    void HandleShopInput();

    void HandleInventoryInput();

    void HandleStatusInput();

    void HandleStoryInput();

    void StartNormalBattle();

    void StartStoryBattleFlow();

    BattleResult StartMiddleBossBattle();

    BattleResult StartFinalBossBattle();

    bool ShowCharacterPreview(int choice);

    void RenderSellItemList();

   


    // ����

    void Ending();

    void GameOver();

    // �α�

    void AddLog(const std::string& text);
};
